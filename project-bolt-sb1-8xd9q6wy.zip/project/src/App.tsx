import React from 'react';
import DecisionTree from './components/DecisionTree';

function App() {
  return <DecisionTree />;
}

export default App;